from helper import add_file_to_bucket, extract_date, extract_time

def transform_workouts(data):
    return "lol"