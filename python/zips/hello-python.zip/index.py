def lambda_handler(event, context):
   return {
       'message' : "TESTING HELLO WORLD!!!!",
       'event': event
   }